/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cpit251_group2;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author 96653
 */
public class ClientTest {
    
    public ClientTest() {
    }

    /**
     * Test of getUserName method, of class Client.
     */
    @Test
    public void testGetUserName() {
    }

    /**
     * Test of getEmail method, of class Client.
     */
    @Test
    public void testGetEmail() {
    }

    /**
     * Test of getPhone method, of class Client.
     */
    @Test
    public void testGetPhone() {
    }

    /**
     * Test of setUserName method, of class Client.
     */
    @Test
    public void testSetUserName() {
    }

    /**
     * Test of setEmail method, of class Client.
     */
    @Test
    public void testSetEmail() {
    }

    /**
     * Test of setPhone method, of class Client.
     */
    @Test
    public void testSetPhone() {
    }

    /**
     * Test of toString method, of class Client.
     */
    @Test
    public void testToString() {
    }
    
}
