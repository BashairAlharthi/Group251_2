package cpit251_group2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class CPIT251_Group2 {

    public static void main(String[] args) throws FileNotFoundException {
        Scanner input = new Scanner(System.in);
        PrintWriter output = new PrintWriter("client.txt");

        System.out.println("--- Domestic Serviece Worker ---");
        System.out.println("Welcome Dear Client\n");
        String serviece;
        System.out.println("You need a serviece? yes/no");

        serviece = input.next();
        if(serviece.matches("yes")){
        ////////////////////////////// User Info /////////////////////////////////////////////////////
            System.out.println("Please enter your information :-\n");
            System.out.println("Please enter your Full Name: ");
            String username = input.nextLine();
            input.nextLine();
            output.println(username);
            System.out.println("Please enter your Email: ");
            String email = input.next();
            output.println(email);
            System.out.println("Please enter your Phone Number: ");
            String phone = input.next();
            output.println(phone);
        }
        
            
            ////////////////////////////////// Main Menu ////////////////////////////////////////////////
            System.out.println("\nPlease select your service from the Main Menu below :");
            System.out.println("a : Plumber ");
            System.out.println("b : Electrician ");
            System.out.println("c : Carpenter");
            System.out.println("d : Exit");
            String Schoice = input.next(); // user choice of serviece 

            String Wchoice; // user choice of Worker
            String Wname; // Worker name
            String Wtime; // user choice of visit time

        while (Schoice!="d") {

            ///////////////////////////////// Plumber ////////////////////////////////////////////////////
            if (Schoice.matches("a")) {
                System.out.println("Here is a list of Plumber Workers availble ");
                System.out.println("1 . Ahmed Fadel ( 10:00AM ) ***");
                System.out.println("2 . Ahmed Fadel ( 11:00AM ) ***");
                System.out.println("3 . Mohammad Khan ( 4:00PM )****");
                System.out.println("4 . Mohammad Khan ( 6:00PM )****");

                Wchoice = input.next();

                if (Wchoice.matches("1")) {
                    Wname = "Name of Worker :Ahmed Fadel";
                    Wtime = "Time of visit: ( 10:00AM )";

                } else if (Wchoice.matches("2")) {
                    Wname = "Name of Worker :Ahmed Fadel";
                    Wtime = "Time of visit: ( 11:00AM )";

                } else if (Wchoice.matches("3")) {
                    Wname = "Name of Worker :Mohammad Khan";
                    Wtime = "Time of visit: ( 4:00PM )";

                } else if (Wchoice.matches("4")) {
                    Wname = "Name of Worker :Mohammad Khan";
                    Wtime = "Time of visit: ( 6:00PM )";

                } else {
                    System.out.println("Please Choose from the list !!");
                    System.out.println("Here is a list of Plumber Workers availble ");
                    System.out.println("1 . Ahmed Fadel ( 10:00AM ) ***");
                    System.out.println("2 . Ahmed Fadel ( 11:00AM ) ***");
                    System.out.println("3 . Mohammad Khan ( 4:00PM )****");
                    System.out.println("4 . Mohammad Khan ( 6:00PM )****");
                    Wchoice = input.next();
                }
                ///////////////////////////////// Electrician /////////////////////////////////////////////////
            } else if (Schoice.matches("b")) {
                System.out.println("Here is a list of Electrician Workers availble ");
                System.out.println("1 . Saleh Saad ( 11:00AM ) *****");
                System.out.println("2 . Raj Babo ( 12:00PM ) **");
                System.out.println("3 . Ali Eqbal ( 8:00PM ) ***");
                Wchoice = input.next();
                if (Wchoice.matches("1")) {
                    Wname = "Name of Worker :Saleh Saad";
                    Wtime = "Time of visit: ( 11:00AM )";

                } else if (Wchoice.matches("2")) {
                    Wname = "Name of Worker :Raj Babo";
                    Wtime = "Time of visit: ( 12:00PM )";

                } else if (Wchoice.matches("3")) {
                    Wname = "Name of Worker :Ali Eqbal";
                    Wtime = "Time of visit: ( 8:00PM )";

                } else {
                    System.out.println("Please Choose from the list !!");
                    System.out.println("Here is a list of Electrician Workers availble ");
                    System.out.println("1 . Saleh Saad ( 11:00AM ) *****");
                    System.out.println("2 . Raj Babo ( 12:00PM ) **");
                    System.out.println("3 . Ali Eqbal ( 8:00PM ) ***");
                    Wchoice = input.next();
                }

                ///////////////////////////////// Carpenter ////////////////////////////////////////////////////
            } else if (Schoice.matches("c")) {
                System.out.println("Here is a list of Carpenter Workers availble ");
                System.out.println("1 . Khalel Samer ( 1:00PM ) ****");
                System.out.println("2 . Mohammed Ali ( 7:30PM ) **");
                Wchoice = input.next();

                if (Wchoice.matches("1")) {
                    Wname = "Name of Worker :Khalel Samer";
                    Wtime = "Time of visit: ( 1:00PM )";

                } else if (Wchoice.matches("2")) {
                    Wname = "Name of Worker :Mohammed Ali";
                    Wtime = "Time of visit: ( 7:30PM )";

                } else {
                    System.out.println("Please Choose from the list !!");
                    System.out.println("Here is a list of Carpenter Workers availble ");
                    System.out.println("1 . Khalel Samer ( 1:00PM ) ****");
                    System.out.println("2 . Mohammed Ali ( 7:30PM ) **");
                    Wchoice = input.next();
                }
            } 
            else {
                System.out.println("Please Choose from the list !!");
                System.out.println("\nPlease select your service from the Main Menu below :");
                System.out.println("a : Plumber ");
                System.out.println("b : electrician ");
                System.out.println("c : carpenter");
                System.out.println("d : exit");
                Schoice = input.next();
            }
            break;
        }
        System.out.println("Thank you for visitting bye bye !! ");

        output.close();

    }

}
